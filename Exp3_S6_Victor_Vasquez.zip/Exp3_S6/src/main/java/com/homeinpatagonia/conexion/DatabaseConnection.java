package com.homeinpatagonia.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    public Connection crearConexion() {
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviesdb", "admin", "jy{Sf\"%$]C:0v1U}" );
            System.out.println("CONEXION REALIZADA");
        } catch (SQLException e) {
            System.out.println("ERROR EN LA CONEXION " + e.getMessage());
        }
        return conexion;
    }
}