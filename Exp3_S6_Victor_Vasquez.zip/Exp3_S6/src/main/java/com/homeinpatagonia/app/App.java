package com.homeinpatagonia.app;

import com.homeinpatagonia.conexion.DatabaseConnection;

public class App {
    public static void main(String[] args) {
        DatabaseConnection conexion = new DatabaseConnection();
        conexion.crearConexion();
    }
}
